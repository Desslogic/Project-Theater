

<div class="container">
    <h1 class="eTitle display-3 text-center my-4">Upcoming Shows</h1>
    <div class="row">
            <?php include 'classes/play-card.php';?>
            <?php include 'classes/play-card.php';?>
            <?php include 'classes/play-card.php';?>
            <?php include 'classes/play-card.php';?>
            <?php include 'classes/play-card.php';?>
            <?php include 'classes/play-card.php';?>

    </div>
</div>
