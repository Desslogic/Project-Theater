<div class="col-md-6 col-lg-4">
        <!-- Card -->
            <div class="card mb-3 text-white black text-center">
            <div class="row">
                <div class="thumbnail text-center">
                    <img class="card-img-top darker" src="images/placeholder.png" alt="Play Name">
                    <div class="caption">
                        <h1 class="card-title eTitle">Here the name of the play</h3>
                    </div>
                </div>
            </div>
                <div class="card-body">
                    <p class="card-text">Short just this line so it doesn't deform the element</p>
                    <p class="card-text fw-bold">
                        3/18/2022
                        <button type="button" class="btn btn-secondary btn-sm">Purchase</button>
                    </p>
                </div>
            </div>
        </div>