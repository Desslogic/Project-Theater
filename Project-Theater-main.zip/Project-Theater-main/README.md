# Project-Theater

Project for CS472 Software Engineering 

<p><strong>Team members</strong></p>
<ul>
	<li>Brian Elder</li>
	<li>Pedro Damian Marta</li>
	<li>Preston Feagan</li>
	<li>Skyler Landess</li>
</ul>
</p>

<p><strong>Stage 0 Team Leader:</strong> Pedro Damian Marta</p>

<p><strong>Stage 1 Team Leader:</strong> Brian Elder</p>

<p><strong>Stage 2 Team Leader:</strong> Preston Feagan</p>

<p><strong>Stage 3 Team Leader:</strong> Pedro Damian Marta</p>

<p><strong>Stage 4 Team Leader:</strong> Skyler Landess</p>

